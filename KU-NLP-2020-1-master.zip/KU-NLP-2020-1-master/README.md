# KU-NLP-2020-1
2020-1학기 고려대학교 컴퓨터학과 자연어처리(COSE461) 및 인공지능과 자연어처리 기술 실습자료(DFC615)

## 실습순서
#### Part01: 자연언어처리기초 및 텍스트 전처리 (토큰화, 형태소분석, 구문분석 등) <br>
#### Part02: Keras 기초 <br>
#### Part03: CNN(Convolution Neural Network)을 이용한 Sentiment Analysis<br>

##
제작자: Park Chanjun (박찬준) <br>
소속: Korea University Natural Language Processing & Artificial Intelligence Lab (고려대학교 자연언어처리&인공지능 연구실)<br>
Email: bcj1210@naver.com<br>

## 
참고자료: 케라스 창시자에게 배우는 딥러닝
